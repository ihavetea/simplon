// INSTRUCTIONS STEP2 -->
// Créez les variables "integer", "float", "string", "bool", "null", "array".
// Affectez les valeurs suivantes aux variables dont le nom correspond au type de la valeur :
// true, [], "quarante-deux", 42, NULL et 42.42
